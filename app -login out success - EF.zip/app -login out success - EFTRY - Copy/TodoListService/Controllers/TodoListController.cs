﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using TodoListService.Models;

namespace TodoListService.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class TodoListController : Controller
    {
        static ConcurrentBag<TodoItem> todoStore = new ConcurrentBag<TodoItem>();

        // GET: api/values
        [HttpGet]
        public IEnumerable<TodoItem> Get()
        {
            var options = new DbContextOptionsBuilder<TodoContext>()
      .UseInMemoryDatabase(databaseName: "Test")
      .Options;
            using (var context = new TodoContext(options))
            {
                string owner = (User.FindFirst(ClaimTypes.NameIdentifier))?.Value;
                var sreturn = todoStore.Where(t => t.Owner == owner).ToList();
                return context.TodoList.Where(t => t.Owner == owner).ToList();
            }
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]TodoItem Todo)
        {
            var options = new DbContextOptionsBuilder<TodoContext>()
     .UseInMemoryDatabase(databaseName: "Test")
     .Options;
            using (var context = new TodoContext(options))
            {
                string owner = (User.FindFirst(ClaimTypes.NameIdentifier))?.Value;
                context.TodoList.Add(new TodoItem { Owner = owner, Title = Todo.Title });
                context.SaveChanges();
                todoStore.Add(new TodoItem { Owner = owner, Title = Todo.Title });
            }
        }
    }
}
