﻿namespace ProductWebApp.Models
{
    public class ProductItem
    {
        public string Owner { get; set; }
        public string Title { get; set; }
    }
}
