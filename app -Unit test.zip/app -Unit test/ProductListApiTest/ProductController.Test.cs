using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit;
using NUnit.Framework;
using ProductService.Commands;
using ProductService.Controllers;
using ProductService.Models;
using ProductService.Services;

namespace ProductListApiTest
{
    public class ProductControllerTest
    {
        private Mock<IProductRepositoryService> mockProductRepositoryService = new Mock<IProductRepositoryService>();
        private ClaimsPrincipal user;
        private Mock<IMediator> mockMediator = new Mock<IMediator>();
        [SetUp]
        public void Setup()
        {
            user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
                     {
                            new Claim(ClaimTypes.Name, "dummy name"),
                            new Claim(ClaimTypes.NameIdentifier, "1"),
                            new Claim("custom-claim", "dummy claim value"),
                     }, "mock"));
        }
        [Test]
        public void GetTestAsync()
        {
            string userToken = (user.FindFirst(ClaimTypes.NameIdentifier))?.Value;
            mockProductRepositoryService.Setup(x => x.GetAllProducts(userToken)).Returns(GetAllProducts());
            var controller = new ProductController(mockProductRepositoryService.Object, mockMediator.Object);
            var response = controller.Get().Result as OkObjectResult;
            Assert.IsInstanceOf<IEnumerable<ProductItem>>(response.Value);
        }
        [Test]
        public void PostTestAsync()
        {
            var productItemAddCommand = new ProductItemAddCommand();
            mockMediator.Setup(x => x.Send(It.IsAny<ProductItemAddCommand>(), new CancellationToken())).Returns(Task.FromResult(GetProductItem()));
            var controller = new ProductController(mockProductRepositoryService.Object, mockMediator.Object);
            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user }
            };
            var actionResult = controller.Post(new ProductItemAddCommand { });
            Assert.IsInstanceOf<ActionResult<ProductItem>>(actionResult);
        }
        private ProductItem GetProductItem()
        {
            return new ProductItem
            {
                Id = 1,
                Owner = "Test",
                Title = "Sam"
            };
        }
        private List<ProductItem> GetAllProducts()
        {
            var todoList = new List<ProductItem> {
                 new ProductItem { Title = "Product One" },
                 new ProductItem { Title = "Product Two" }
               };
            return todoList;

        }
    }
}
