﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using ProductService.Models;
using ProductService.Services;
using MediatR;
using ProductService.Commands;
using System.Threading.Tasks;

namespace ProductService.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class ProductController : Controller
    {
        static ConcurrentBag<ProductItem> ProductStore = new ConcurrentBag<ProductItem>();
        private readonly IProductRepositoryService _productRepositoryService;
        private readonly IMediator _mediator;

        public ProductController(IProductRepositoryService Productrepositoryservice, IMediator Mediator)
        {
            _mediator = Mediator;
            _productRepositoryService = Productrepositoryservice;
        }
        // GET: api/values
        [HttpGet]
        public ActionResult<ProductItem> Get()
        {
            string owner = (User.FindFirst(ClaimTypes.NameIdentifier))?.Value;
            return Ok(_productRepositoryService.GetAllProducts(owner));
        }

        // POST api/values
        [HttpPost]
        public ProductItem Post([FromBody]ProductItemAddCommand Product)
        {
            Product.Owner = (User.FindFirst(ClaimTypes.NameIdentifier))?.Value;
            Task<ProductItem> createdProduct = _mediator.Send(Product);
            return new ProductItem { Id = createdProduct.Result.Id, Owner = createdProduct.Result.Owner, Title = createdProduct.Result.Title };
        }
    }
}
