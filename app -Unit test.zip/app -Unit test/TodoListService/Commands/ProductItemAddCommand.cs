﻿#region Namespaces
using MediatR;
#endregion

namespace ProductService.Commands
{
    public class ProductItemAddCommand : IRequest<Models.ProductItem>
    {
        public string Owner { get; set; }
        public string Title { get; set; }

    }
}
