﻿using MediatR;
using ProductService.Commands;
using ProductService.Models;
using ProductService.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ProductService.Handlers.CommandHandler
{
    public class ProductCommandHandler : IRequestHandler<ProductItemAddCommand, ProductItem>
    {
        private readonly IProductRepositoryService _productRepositoryService;
        public ProductCommandHandler(IProductRepositoryService ProductRepositoryService)
        {
            _productRepositoryService = ProductRepositoryService;
        }
      
        public async Task<ProductItem> Handle(ProductItemAddCommand request, CancellationToken cancellationToken)
        {
            ProductItem newItem = new ProductItem { Owner = request.Owner, Title = request.Title };
            return await _productRepositoryService.AddProductItem(newItem);
        }
    }
}
