﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProductListService.Models;

namespace ProductListService.Services
{
    public class ProductsRepositoryService : IProductsRepositoryService
    {
        private readonly ProductContext _productContext;
        public ProductsRepositoryService(ProductContext productContext)
        {
            _productContext = productContext;
        }

        public List<ProductItem> GetAllProducts(string owner)
        {
            var options = new DbContextOptionsBuilder<ProductContext>()
      .UseInMemoryDatabase(databaseName: "ProductsDB")
      .Options;
            using (var context = new ProductContext(options))
            {
                return context.ProductList.Where(t => t.Owner == owner).ToList();
            }
        }
        public async Task<ProductItem> AddProductItem(ProductItem NewProduct)
        {
            try
            {
                var options = new DbContextOptionsBuilder<ProductContext>()
       .UseInMemoryDatabase(databaseName: "ProductsDB")
       .Options;
                using (var context = new ProductContext(options))
                {
                    context.ProductList.Add(new ProductItem { Owner = NewProduct.Owner, Title = NewProduct.Title });
                    await context.SaveChangesAsync();
                }
            }
            //Not using any exception variable as not performing any operation on exception
            //Thus left as (Exception)
            catch (Exception)
            {
                //To do(Not doing for Hands on excercise) : Log service level exception and throw appropriate exception code               
            }
            return NewProduct;
        }
    }
}
