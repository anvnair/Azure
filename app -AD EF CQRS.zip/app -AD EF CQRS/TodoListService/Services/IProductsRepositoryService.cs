﻿using ProductListService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductListService.Services
{
    public interface IProductsRepositoryService
    {
        List<ProductItem> GetAllProducts(string owner);
        Task<ProductItem> AddProductItem(ProductItem NewProduct);
    }
}


