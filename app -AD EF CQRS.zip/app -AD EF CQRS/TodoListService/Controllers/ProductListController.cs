﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using ProductListService.Models;
using ProductListService.Services;
using MediatR;
using ProductListService.Commands;

namespace ProductListService.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class ProductListController : Controller
    {
        static ConcurrentBag<ProductItem> ProductStore = new ConcurrentBag<ProductItem>();
        private readonly IProductsRepositoryService _productRepositoryService;
        private readonly IMediator _mediator;

        public ProductListController(IProductsRepositoryService Productrepositoryservice, IMediator Mediator)
        {
            _mediator = Mediator;
            _productRepositoryService = Productrepositoryservice;
        }
        // GET: api/values
        [HttpGet]
        public ActionResult<ProductItem> Get()
        {
            string owner = (User.FindFirst(ClaimTypes.NameIdentifier))?.Value;
            return Ok(_productRepositoryService.GetAllProducts(owner));
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]ProductItemAddCommand Product)
        {
            Product.Owner = (User.FindFirst(ClaimTypes.NameIdentifier))?.Value;
            var result = _mediator.Send(Product);
        }
    }
}
