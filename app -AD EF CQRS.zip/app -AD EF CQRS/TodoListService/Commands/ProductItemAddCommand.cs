﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductListService.Commands
{
    public class ProductItemAddCommand : IRequest<Models.ProductItem>
    {
        public string Owner { get; set; }
        public string Title { get; set; }

    }
}
