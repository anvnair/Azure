﻿using MediatR;
using ProductListService.Commands;
using ProductListService.Models;
using ProductListService.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ProductListService.Handlers.CommandHandler
{
    public class ProductCommandHandler : IRequestHandler<ProductItemAddCommand, ProductItem>
    {
        private readonly IProductsRepositoryService _productRepositoryService;
        public ProductCommandHandler(IProductsRepositoryService ProductRepositoryService)
        {
            _productRepositoryService = ProductRepositoryService;
        }
      
        public async Task<ProductItem> Handle(ProductItemAddCommand request, CancellationToken cancellationToken)
        {
            ProductItem newItem = new ProductItem { Owner = request.Owner, Title = request.Title };
            return await _productRepositoryService.AddProductItem(newItem);
        }
    }
}
